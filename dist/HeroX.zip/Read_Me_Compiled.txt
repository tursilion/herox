This game was compiled from TI BASIC/TI EXTENDED BASIC by TMOP in 2020.

Some fixes/enhancements/etc. could have been added to the original code.

Have fun!


- Sept 2020 by TMOP

